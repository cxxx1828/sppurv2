
#pragma once

#define LOOP_HZ 25

#define BAUDRATE 115200
#define UART_DEV_PATTERN "/dev/ttyUSB0"

#define N_JOINTS 4
