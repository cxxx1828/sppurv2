
#ifndef exec_hpp
#define exec_hpp

#include <string>

std::string exec(const std::string& cmd);


#endif /* exec_hpp */
