#pragma once

#define DEV "/dev/ttyUSB1"
#define BAUD_RATE 115200

#define F_SMPL 1000
#define LOG2_SAMPLES 7
